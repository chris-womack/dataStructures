// Chris Womack
// Dr. Hoenigman
// Assignment III

#include "bst.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <cstdlib>

using namespace std;
//***************************************************************************//
// Book Books
//***************************************************************************//
// Book constructor
Book::Book(){
    // string isbn
    string ISBN = "NULL";

    // int isbn
    long long ISBN_int = 0;

    // title
    string title = "NULL";

    // author
    string author = "NULL";

    // convert first letter of author to ASCII for comparison
    int ASCII_1 = 0;

    // convert first letter of author to ASCII for comparison
    int ASCII_2 = 0;

    // convert first letter of author to ASCII for comparison
    int ASCII_3 = 0;

    // convert price to int for compare
    float price = 0;

    string price_str = "NULL";

    // convert stock to int for compare
    int stock = 0;

    Book* left = NULL;
    Book* right = NULL;
    Book* parent = NULL;
}
// Book destructor
Book::~Book(){}

// get and set ISBN
string Book::getISBN(){
    return ISBN;
}
void Book::setISBN(string number){
    ISBN = number;
}

// get and set ISBN
long long Book::getISBN_int(){
    return ISBN_int;
}
void Book::setISBN_int(string number){
    number.erase(0,6);
    stringstream ss(number);
    ss >> ISBN_int;
}

// get and set title
string Book::getTitle(){
    return title;
}
void Book::setTitle(string name){
    title = name;
}

// get and set author
string Book::getAuthor(){
    return author;
}
void Book::setAuthor(string name){
    author = name;
}

// get and set ASCII
int Book::getASCII_1(){
    return ASCII_1;
}
void Book::setASCII_1(string name){
    char ch;
    ch = name.at(0);
    ASCII_1 = int(ch);
}

// get and set ASCII
int Book::getASCII_2(){
    return ASCII_2;
}
void Book::setASCII_2(string name){
    char ch;
    ch = name.at(1);
    ASCII_2 = ch;
}

// get and set ASCII
int Book::getASCII_3(){
    return ASCII_3;
}
void Book::setASCII_3(string name){
    char ch;
    ch = name.at(2);
    ASCII_3 = ch;
}

// get and set price
string Book::getPrice_str(){
    return price_str;
}
void Book::setPrice_str(string number){
    price_str = number;
}
float Book::getPrice(){
    return price;
}
void Book::setPrice(string number){
    stringstream sstr(number);
    sstr >> price;
}

// get and set stock
int Book::getStock(){
    return stock;
}
void Book::setStock(string number){
    stringstream sstr_s(number);
    sstr_s >> stock;
}
void Book::setStock_int(int number){
    stock = number;
}


// get the left child
Book* Book::getLeft(){
    return left;
}
// set the left child
void Book::setLeft(Book*n){
    left = n;
}

// get the right child
Book* Book::getRight(){
    return right;
}
// set the right child
void Book::setRight(Book*n){
    right = n;
}

// get the parent
Book* Book::getParent(){
    return parent;
}
// set the parent
void Book::setParent(Book*n){
    parent = n;
}



//***************************************************************************//
// BST Single (Uses Book but doesn't use ->next)
//***************************************************************************//
// BST constructor
BST::BST(Book* root){
    Head = root;
    current = NULL;
    par = NULL;
    tmp = NULL;
}
// BST destructor
BST::~BST(){}


Book* BST::getHead(){
    return Head;
}
void BST::setHead(Book* Node){
    Head = Node;
}

Book* BST::getCurrent(){
    return current;
}
void BST::setCurrent(Book* Node){
    current = Node;
}

Book* BST::getTmp(){
    return tmp;
}
void BST::setTmp(Book* Node){
    tmp = Node;
}



// BST insert book into tree
// Inserts books into BST based on the Author name.
BST* BST::insertBook(string aut, string til, string IS, string pri, string sto){

    tmp = new Book();
    tmp->setAuthor(aut);
    tmp->setTitle(til);
    tmp->setISBN(IS);
    tmp->setISBN_int(IS);
    tmp->setASCII_1(aut);
    tmp->setASCII_2(aut);
    tmp->setASCII_3(aut);
    tmp->setPrice(pri);
    tmp->setPrice_str(pri);
    tmp->setStock(sto);
    tmp->setLeft(NULL);
    tmp->setRight(NULL);

    par = NULL;
    current = Head;

    while(current != NULL){
        par = current;
        if(tmp->getISBN_int() < current->getISBN_int()){
            current = current->getLeft();
            //cout << "went left" << endl;
        }else{
            current = current->getRight();
            //cout << "went right" << endl;
        }
    }

    tmp->setParent(par);
    if(tmp->getISBN_int() < par->getISBN_int()){
        par->setLeft(tmp);
        //cout << "   placed left" << endl;
    }else{
        par->setRight(tmp);
        //cout << "   placed right" << endl;
    }
    /*
    while(current != NULL){
        par = current;
        if(tmp->getASCII_1() < current->getASCII_1()){
            current = current->getLeft();
            //cout << "went left" << endl;
        }else if(tmp->getASCII_1() == current->getASCII_1() and tmp->getASCII_2() < current->getASCII_2()){
            current = current->getLeft();
            //cout << "went left" << endl;
        }else if(tmp->getASCII_1() == current->getASCII_1() and tmp->getASCII_2() == current->getASCII_2() and tmp->getASCII_3() < current->getASCII_3()){
            current = current->getLeft();
            //cout << "went left" << endl;
        }else if(tmp->getASCII_1() == current->getASCII_1() and tmp->getASCII_2() == current->getASCII_2() and tmp->getASCII_3() == current->getASCII_3()){
            if(tmp->getPrice() < current->getPrice()){
                current = current->getLeft();
                //cout << "went left" << endl;
            }else{
                current = current->getRight();
                //cout << "went right" << endl;
            }
        }else{
            current = current->getRight();
            //cout << "went right" << endl;
        }
    }*/
    /*
    if(tmp->getASCII_1() < par->getASCII_1()){
        par->setLeft(tmp);
    }else if(tmp->getASCII_1() == par->getASCII_1() and tmp->getASCII_2() < par->getASCII_2()){
        par->setLeft(tmp);
    }else if(tmp->getASCII_1() == par->getASCII_1() and tmp->getASCII_2() == par->getASCII_2() and tmp->getASCII_3() < par->getASCII_3()){
        par->setLeft(tmp);
    }else if(tmp->getASCII_1() == par->getASCII_1() and tmp->getASCII_2() == par->getASCII_2() and tmp->getASCII_3() == par->getASCII_3()){
        if(tmp->getPrice() < par->getPrice()){
           par->setLeft(tmp);
        }else{
            par->setRight(tmp);
        }
    }else{
        par->setRight(tmp);
    }
    */

}

// BST sell a book in the tree
// Given the title or ISBN find a book and sell it.
BST* BST::sellBook(){
    int stock_sell;
    stock_sell = current->getStock();
    stock_sell--;
    current->setStock_int(stock_sell);
}
// print the entire tree
// Prints the entire inventory based on Author name.
/*
Book* BST::printInventory(Book* node){
    int value;
    Book* returnNode;
    //currentNode = node;


    //cout << current->getISBN() << endl;
    //cout << current->getTitle() << endl;

    if(current != NULL and current->getLeft() == NULL and current->getRight() == NULL){
        cout << "break last loop" << endl;
        cout << node->getISBN() << endl;
        return node;
    }else if(node->getLeft() != NULL and node->getRight() != NULL){
        cout << "break two child" << endl;
        returnNode = printInventory(node->getLeft());
        cout << returnNode->getISBN() << endl;
        returnNode = printInventory(node->getRight());
        cout << returnNode->getISBN() << endl;
    }else if(node->getLeft() == NULL and node->getRight() != NULL){
        cout << "break right child" << endl;
        returnNode = printInventory(node->getRight());
        cout << returnNode->getISBN() << endl;
    }else if(node->getLeft() != NULL and node->getRight() == NULL){
        cout << "break left child" << endl;
        returnNode = printInventory(node->getLeft());
        cout << returnNode->getISBN() << endl;
    }
}
*/
// print bargain books
// Prints the all books lower or equal to bargain price.
BST* BST::printBargain(){
}

Book* searchISBN(BST* library, Book* current, long long key){
    library->setCurrent(current);

    //cout.precision(15);
    //cout << library->getCurrent()->getISBN_int() << endl;
    //cout << key << endl;

    if(library->getCurrent()->getISBN_int() == key or library->getCurrent() == NULL){
        return library->getCurrent();
    }

    if(key < library->getCurrent()->getISBN_int()){
        // cout << "went left" << endl;
        searchISBN(library, library->getCurrent()->getLeft(), key);

    }else{
        // cout << "went right" << endl;
        searchISBN(library, library->getCurrent()->getRight(), key);

    }
}

void printInv(Book* root){
    Book* returnNode;
    returnNode = root;

    if(root->getLeft() == NULL){
        if(root->getStock() > 0){
            cout << root->getISBN() << endl;
        }
    }else{
        printInv(root->getLeft());
        if(root->getStock() > 0){
        cout << root->getISBN() << endl;
        }
    }

    if(root->getRight() == NULL){
    }else{
        printInv(root->getRight());
    }
}

void printBar(Book* root, float price){
    Book* returnNode;
    returnNode = root;

    if(root->getLeft() == NULL){
        if(root->getStock() > 0 and root->getPrice() <= price){
            cout << endl;
            cout << root->getTitle() << endl;
            cout << root->getISBN() << endl;
            cout << "Price $" << root->getPrice_str() << endl;
        }
    }else{
        printBar(root->getLeft(), price);
        if(root->getStock() > 0 and root->getPrice() <= price){
        cout << endl;
        cout << root->getTitle() << endl;
        cout << root->getISBN() << endl;
        cout << "Price $" << root->getPrice_str() << endl;
        }
    }

    if(root->getRight() == NULL){
    }else{
        printBar(root->getRight(), price);
    }
}
