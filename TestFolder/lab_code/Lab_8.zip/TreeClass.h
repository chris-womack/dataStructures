// Chris Womack
// Lab_8

#ifndef LINKEDLISTEX_H_INCLUDED
#define LINKEDLISTEX_H_INCLUDED

#include <string>

using namespace std;

class City{
private:
	string name;        // key
	City *leftChild;    // left
	City *rightChild;   // right
	City *parent;       // parent

public:
	// constructor/destructor
	City(string);
	~City();

	// get and set left
	City *getLeftChild();
	void setLeftChild(City *n);

	// get and set right
	City *getRightChild();
	void setRightChild(City *p);

	// get and set parent
	City *getParent();
	void setParent(City *p);

	// get and set name
    string getName();
    void setName(string l);
};

class Tree{
private:
    City *root;     // root node of tree
    City *current;  // current node of tree
    City *tmp;      // tmp node
public:
    Tree();
    ~Tree();

    // add a city given parent and new city
    void addCity(City *Node, string prnt_city, string new_city, int *city_count);
    int CountNodes(City *Node);
    int CountNodes_R(City *Node);
};

#endif // LINKEDLISTEX_H_INCLUDED
