// Chris Womack
// Lab_8

#include <iostream>
#include "TreeClass.h"
#include <string>
using namespace std;

//***************************************************************************//
// City Nodes
//***************************************************************************//
City::City(string n){
	name = n;
    leftChild = NULL;
    rightChild = NULL;
    parent = NULL;
}
City::~City(){
    cout<<"calling destructor"<<endl;
}

// get set left
void City::setLeftChild(City *n){
    leftChild = n;
}
City* City::getLeftChild(){
	return leftChild;
}

// get set right
void City::setRightChild(City *n){
    rightChild = n;
}
City* City::getRightChild(){
	return rightChild;
}

// get set parent
void City::setParent(City *n){
    parent = n;
}
City* City::getParent(){
	return parent;
}

// get set name
string City::getName(){
    return name;
}
void City::setName(string l){
    name = l;
}

//***************************************************************************//
// Tree Class
//***************************************************************************//
Tree::Tree(){
    root = NULL;
}
Tree::~Tree(){
        //will need to delete all cities in the tree
}

// adds city using recursion
void Tree::addCity(City* Node, string prnt_city, string new_city, int * city_count){;
            // check for a left node and the name
            if(Node->getLeftChild() != NULL && Node->getName() != prnt_city){
                cout << "going down left" << endl;
                // call addCity again traversing downt the left node
                addCity(Node->getLeftChild(), prnt_city, new_city, city_count);
                cout << "returning left" << endl;
            }
            // check for a right node and the name
            if(Node->getRightChild() != NULL && Node->getName() != prnt_city){
                cout << "going down right" << endl;
                // call addCity again traversing down the right node
                addCity(Node->getRightChild(), prnt_city, new_city, city_count);
                cout << "returning right" << endl;
            }

            // once the previous code finds the node
            if(Node->getName() == prnt_city){
                tmp = new City(new_city);               // create new node
                cout << "New city created" << endl;
                // try to set left first
                if(Node->getLeftChild() == NULL){
                    Node->setLeftChild(tmp);
                    (*city_count)++;
                    cout << "Left Node added" << endl;
                // then if not NULL set right
                }else if(Node->getRightChild() == NULL){
                    Node->setRightChild(tmp);
                    (*city_count)++;
                    cout << "Right Node added" << endl;
                }else{
                    cout << "The Parent Node is full." << endl;
                }
            }
}

/*
int Tree::CountNodes(City *Node){
    int counter = 0;
    if(Node != NULL and Node->getLeftChild() == NULL and Node->getRightChild() == NULL){
        return counter++;
    }else{
        if(Node->getLeftChild() != NULL)
            counter++;
        if(Node->getRightChild() != NULL)
            counter++;
    }

}
*/

int Tree::CountNodes_R(City *Node){
    // empty tree
    if(Node == NULL){
        cout << "City tree is empty, please add cities." << endl;
    // base case: node with no children
    }else if(Node != NULL and Node->getLeftChild() == NULL and Node->getRightChild() == NULL){
        return 1;
    // all other cases
    }else{
        // case 1: node with two children
        if(Node->getLeftChild() != NULL and Node->getRightChild() != NULL){
            return (CountNodes_R(Node->getLeftChild()) + CountNodes_R(Node->getRightChild()) + 1);
        // case 2: node with only a left child
        }else if(Node->getLeftChild() != NULL and Node->getRightChild() == NULL){
            return (CountNodes_R(Node->getLeftChild()) + 1);
        }
    }
}

