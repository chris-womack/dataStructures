#ifndef MYSTRUCT_H_INCLUDED
#define MYSTRUCT_H_INCLUDED

#include <iostream>
#include <string>

using namespace std;

struct arrayStruct {
    int numGuess;
    int xSize;
    int ySize;
    int opCount;
};


#endif // MYSTRUCT_H_INCLUDED
